package com.example.survivalhelper;

public final class FeatureState {
    private FeatureState() {}

    public static boolean xrayEnabled = false;
    public static boolean hostileEspEnabled = false;
    public static boolean autoAttackEnabled = false;
    public static boolean autoEatEnabled = false;
    public static boolean sprintEnabled = false;
    public static boolean fullbrightEnabled = false;
    public static boolean coordinatesHudEnabled = true;
    public static boolean durabilityWarningsEnabled = true;

    public static double attackRange = 3.5;
    public static float autoEatHungerThreshold = 16.0f;
}
