package com.example.survivalhelper;

import net.minecraftforge.fml.common.Mod;

@Mod(SurvivalHelper.MOD_ID)
public final class SurvivalHelper {
    public static final String MOD_ID = "survivalhelper";

    public SurvivalHelper() {
        // Client feature/event registration must be implemented against
        // the exact Forge 26.2-65.1.6 client API before this is a functional mod.
    }
}
