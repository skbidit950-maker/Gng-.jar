package com.example.survivalhelper;

import java.util.List;

public final class FeatureRegistry {
    private FeatureRegistry() {}

    public record Feature(String id, String category, String description) {}

    public static final List<Feature> ALL = List.of(
        new Feature("xray", "World", "Highlight selected ores"),
        new Feature("hostile_esp", "Combat", "Outline hostile mobs and show distance"),
        new Feature("auto_attack", "Combat", "Attack visible hostile mobs in range"),
        new Feature("auto_eat", "Survival", "Eat when hunger is low"),
        new Feature("sprint", "Movement", "Keep sprint enabled while moving"),
        new Feature("fullbright", "World", "Increase local scene brightness"),
        new Feature("coordinates", "HUD", "Display coordinates, biome and dimension"),
        new Feature("durability", "Alerts", "Warn when equipped gear is nearly broken")
    );
}
