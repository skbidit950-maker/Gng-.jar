# Build from Android using GitHub Actions

This project includes the exact Forge MDK ZIP you supplied and a GitHub Actions workflow.

1. Create a GitHub repository and upload the contents of this folder (not the ZIP itself).
2. Open the repository's **Actions** tab.
3. Select **Build Survival Helper** and tap **Run workflow**.
4. Wait for the workflow to finish.
5. Open the successful workflow run and download the `survival-helper-jar` artifact.
6. Extract the artifact and place the JAR in your Minecraft `mods` folder for a matching Forge 26.2 profile.

IMPORTANT:
This is currently a buildable project scaffold, not a feature-complete mod. X-Ray rendering,
GUI, mob ESP, auto-attack, auto-eat, and HUD event implementations still need to be coded
and tested against Forge 26.2-65.1.6. A successful build at this stage only verifies the
scaffold compiles; it does not mean those features work yet.
